import { Component, ViewChild } from "@angular/core";
import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexXAxis,
  ApexPlotOptions,
  ApexStroke
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  xaxis: ApexXAxis;
  stroke: ApexStroke;
};


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: any;
  constructor() {
    this.chartOptions = {
     
      series: [
        {
          name: "Actual Rating",
          data: [0.6, 1.05, 2.4, 1.5, 0.75]
        },
        {
          name: "Ideal Rating",

          data: [0.75, 1.5, 5.8, 2.25, 2]
        }
      ],
      title: {
        text: "My First Angular Chart",
        offsetX: 350
      },
      chart: {
        type: "bar",
        height: 430
      },
      plotOptions: {
        bar: {
          horizontal: true,
          dataLabels: {
            position: "top"
          }
        }
      },
      dataLabels: {
        enabled: false,
        offsetX: -6,
        style: {
          fontSize: "12px",
          colors: ["#fff"]
        }
      },
      stroke: {
        show: true,
        width: 1,
        colors: ["#fff"]
      },
      xaxis: {
        categories: ["COE","VDI","Remote working Enablement","BYOD" ,"Device Coverage"]
      }
    };
  }
}


